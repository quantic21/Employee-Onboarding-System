import json
import boto3
import os
from datetime import datetime

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['TABLE_NAME'])


def lambda_handler(event, context):

    try:
        employee_id = event["employee_id"]

        # ----------------------------
        # FINAL STAGE UPDATE
        # ----------------------------
        table.update_item(
            Key={"employee_id": employee_id},
            UpdateExpression="""
                SET onboarding_status.manager_intro = :v,
                    progress_percent = :progress,
                    overall_status = :overall,
                    updated_at = :time
            """,
            ExpressionAttributeValues={
                ":v": "completed",
                ":progress": 100,
                ":overall": "COMPLETED",
                ":time": datetime.utcnow().isoformat()
            }
        )

        # ----------------------------
        # RESPONSE
        # ----------------------------
        return {
            "employee_id": employee_id,
            "stage": "manager_intro",
            "status": "completed",
            "message": "Onboarding fully completed"
        }

    except Exception as e:
        return {
            "employee_id": event.get("employee_id", "unknown"),
            "stage": "manager_intro",
            "status": "error",
            "error": str(e)
        }