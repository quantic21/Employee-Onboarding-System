import json
import requests
import os

COGNITO_DOMAIN = "https://project-dev-12345.auth.ap-south-1.amazoncognito.com"
CLIENT_ID = os.environ["CLIENT_ID"]
REDIRECT_URI = "https://dqbzdam1n62iw.cloudfront.net"

def lambda_handler(event, context):

    try:
        code = event["queryStringParameters"]["code"]

        token_url = f"{COGNITO_DOMAIN}/oauth2/token"

        headers = {
            "Content-Type": "application/x-www-form-urlencoded"
        }

        data = {
            "grant_type": "authorization_code",
            "client_id": CLIENT_ID,
            "code": code,
            "redirect_uri": REDIRECT_URI
        }

        response = requests.post(token_url, data=data, headers=headers)
        tokens = response.json()

        return {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "*",
                "Access-Control-Allow-Methods": "GET,OPTIONS"
            },
            "body": json.dumps({
                "id_token": tokens.get("id_token"),
                "access_token": tokens.get("access_token"),
                "refresh_token": tokens.get("refresh_token")
            })
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "headers": {
                "Access-Control-Allow-Origin": "*"
            },
            "body": json.dumps({"error": str(e)})
        }