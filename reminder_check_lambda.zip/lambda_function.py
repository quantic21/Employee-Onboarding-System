import boto3
import os

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['TABLE_NAME'])

# ✅ Force region (important)
ses = boto3.client('ses', region_name='ap-south-1')

FROM_EMAIL = os.environ["FROM_EMAIL"]


def lambda_handler(event, context):

    print("🔥 EVENT:", event)

    # ================= GET EMPLOYEE ID =================
    employee_id = event.get("employee_id")

    if not employee_id:
        print("❌ Missing employee_id in event")
        return {
            "employee_id": None,
            "status": "FAILED"
        }

    # ================= FETCH EMPLOYEE =================
    response = table.get_item(Key={"employee_id": employee_id})
    item = response.get("Item")

    if not item:
        print("❌ Employee not found")
        return {
            "employee_id": employee_id,
            "status": "NOT_FOUND"
        }

    # ================= DATA =================
    status = item.get("overall_status", "IN_PROGRESS")
    email = item.get("email")
    name = item.get("name", "there")

    print("📌 STATUS:", status)
    print("📧 EMAIL:", email)
    print("📨 FROM_EMAIL:", FROM_EMAIL)

    # ================= VALIDATION =================
    if not email:
        print("❌ Email missing in DynamoDB")
        return {
            "employee_id": employee_id,
            "status": status
        }

    # ================= SEND REMINDER =================
    if status != "COMPLETED":

        print("🚀 Entering SES block")

        try:
            response = ses.send_email(
                Source=FROM_EMAIL,
                Destination={
                    "ToAddresses": [email]
                },
                Message={
                    "Subject": {
                        "Data": "HRMS Onboarding Reminder"
                    },
                    "Body": {
                        "Text": {
                            "Data": f"""
Hello {name},

This is a reminder that your onboarding documents are still pending.

Current Status: {status}

Please complete your document submission as soon as possible.

Regards,
HR Team
"""
                        }
                    }
                }
            )

            print("✅ SES RESPONSE:", response)

        except Exception as e:
            print("❌ SES FAILED:", str(e))
            raise e   # 🔥 VERY IMPORTANT (forces error visibility)

    else:
        print("✅ Already completed → no reminder sent")

    return {
        "employee_id": employee_id,
        "status": status
    }