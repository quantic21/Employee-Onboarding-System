import json
import boto3
import os
from datetime import datetime

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['TABLE_NAME'])


def lambda_handler(event, context):

    try:
        # Step Functions sends input here
        employee_id = event.get("employee_id", "unknown")

        error = str(event)

        # Update DynamoDB status to FAILED
        table.update_item(
            Key={"employee_id": employee_id},
            UpdateExpression="SET onboarding_status = :s, updated_at = :t",
            ExpressionAttributeValues={
                ":s": "FAILED",
                ":t": datetime.utcnow().isoformat()
            }
        )

        print("❌ ONBOARDING FAILED")
        print("Employee:", employee_id)
        print("Error:", error)

        return {
            "status": "FAILED",
            "employee_id": employee_id,
            "message": "Onboarding workflow failed"
        }

    except Exception as e:
        print("CRITICAL FAILURE:", str(e))
        return {
            "status": "CRITICAL_FAILURE",
            "error": str(e)
        }