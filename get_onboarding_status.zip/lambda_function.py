import json
import boto3
import os

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['TABLE_NAME'])


def lambda_handler(event, context):
    try:
        print("EVENT:", event)

        # -----------------------------
        # FIX: support BOTH API + Step Function
        # -----------------------------
        employee_id = None

        # Case 1: Step Function / direct invoke
        if "employee_id" in event:
            employee_id = event["employee_id"]

        # Case 2: API Gateway path param
        elif event.get("pathParameters"):
            employee_id = event["pathParameters"].get("employee_id")

        if not employee_id:
            return {
                "statusCode": 400,
                "body": json.dumps({
                    "error": "Missing employee_id"
                })
            }

        # -----------------------------
        # Fetch from DynamoDB
        # -----------------------------
        response = table.get_item(Key={"employee_id": employee_id})

        if "Item" not in response:
            return {
                "statusCode": 404,
                "body": json.dumps({
                    "error": "Employee not found"
                })
            }

        item = response["Item"]

        # -----------------------------
        # IMPORTANT: flatten response for Step Function
        # -----------------------------
        onboarding_status = item.get("overall_status", "IN_PROGRESS")

        return {
            "employee_id": employee_id,
            "status": onboarding_status
        }

    except Exception as e:
        print("ERROR:", str(e))
        return {
            "statusCode": 500,
            "body": json.dumps({
                "error": str(e)
            })
        }