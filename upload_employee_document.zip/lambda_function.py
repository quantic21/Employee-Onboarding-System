import json
import boto3
import os
import base64

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(os.environ["TABLE_NAME"])

s3 = boto3.client("s3")
sfn = boto3.client("stepfunctions")
sns = boto3.client("sns")   # ✅ ADDED ONLY

BUCKET = os.environ["BUCKET_NAME"]
STATE_MACHINE_ARN = os.environ["STATE_MACHINE_ARN"]


# ================= RESPONSE =================
def response(status, body):
    return {
        "statusCode": status,
        "headers": {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type,Authorization",
            "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
        },
        "body": json.dumps(body)
    }


# ================= PARSE BODY =================
def parse_body(event):
    body = event.get("body")
    if not body:
        return {}
    try:
        return json.loads(body)
    except:
        return {}


# ================= COGNITO SUB =================
def get_user_sub(event):
    authorizer = event.get("requestContext", {}).get("authorizer", {})

    if "jwt" in authorizer:
        return authorizer["jwt"]["claims"].get("sub")

    if "claims" in authorizer:
        return authorizer["claims"].get("sub")

    return authorizer.get("principalId")


# ================= MAIN =================
def lambda_handler(event, context):

    print("🔥 EVENT:", json.dumps(event))

    try:

        body = parse_body(event)

        # ================= USER =================
        user_sub = get_user_sub(event)

        if not user_sub:
            return response(401, {"error": "Unauthorized - no sub"})

        # ================= FIND EMPLOYEE =================
        scan = table.scan().get("Items", [])
        employee = next((x for x in scan if x.get("cognito_sub") == user_sub), None)

        if not employee:
            return response(404, {"error": "Employee not found"})

        employee_id = employee["employee_id"]

        # ================= VALIDATION =================
        if not body.get("file_content"):
            return response(400, {"error": "Missing file_content"})

        if not body.get("document_type") or not body.get("file_name"):
            return response(400, {"error": "Missing document_type or file_name"})

        # ================= S3 UPLOAD =================
        key = f"{employee_id}/{body['document_type']}/{body['file_name']}"

        s3.put_object(
            Bucket=BUCKET,
            Key=key,
            Body=base64.b64decode(body["file_content"]),
            ContentType=body.get("content_type", "application/octet-stream")
        )

        file_url = f"s3://{BUCKET}/{key}"

        print("✅ Uploaded to S3")

        # ================= UPDATE SINGLE DOCUMENT =================
        table.update_item(
            Key={"employee_id": employee_id},
            UpdateExpression="SET documents.#doc = :val",
            ExpressionAttributeNames={
                "#doc": body["document_type"]
            },
            ExpressionAttributeValues={
                ":val": "completed"
            }
        )

        # ================= CHECK IF ALL DOCS COMPLETED =================
        updated = table.get_item(Key={"employee_id": employee_id}).get("Item", {})
        docs = updated.get("documents", {})

        if docs and all(v == "completed" for v in docs.values()):
            table.update_item(
                Key={"employee_id": employee_id},
                UpdateExpression="SET overall_status = :s",
                ExpressionAttributeValues={
                    ":s": "COMPLETED"
                }
            )

            print("🎉 ALL DOCUMENTS COMPLETED → STATUS UPDATED")

            # ================= SNS NOTIFICATION (ADDED ONLY) =================
            try:
                sns.publish(
                    TopicArn=os.environ["SNS_TOPIC_ARN"],
                    Subject="HRMS Onboarding Completed",
                    Message=f"""
Employee Onboarding Completed Successfully!

Employee ID: {employee_id}
Email: {employee.get('email')}

All documents are uploaded and verified.
"""
                )
                print("📢 SNS SENT")

            except Exception as e:
                print("❌ SNS ERROR:", str(e))

        # ================= STEP FUNCTION =================
        try:
            sfn.start_execution(
                stateMachineArn=STATE_MACHINE_ARN,
                input=json.dumps({
                    "employee_id": employee_id,
                    "document_type": body["document_type"],
                    "file_url": file_url
                })
            )
            print("🚀 Step Function triggered")

        except Exception as e:
            print("❌ Step Function error:", str(e))

        return response(200, {
            "message": "Upload successful",
            "employee_id": employee_id,
            "file_url": file_url
        })

    except Exception as e:
        print("🔥 ERROR:", str(e))
        return response(500, {"error": str(e)})