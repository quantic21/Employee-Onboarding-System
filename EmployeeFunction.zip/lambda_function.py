import json
import uuid
import boto3
import os
import random
import string
from datetime import datetime

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['TABLE_NAME'])

cognito = boto3.client('cognito-idp')
ses = boto3.client('ses')
sfn = boto3.client('stepfunctions')   # ✅ ADDED ONLY

STATE_MACHINE_ARN = os.environ["STATE_MACHINE_ARN"]  # ✅ ADDED ONLY


# ================= RESPONSE =================
def response(status, body):
    return {
        "statusCode": status,
        "headers": {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type,Authorization",
            "Access-Control-Allow-Methods": "OPTIONS,GET,POST"
        },
        "body": json.dumps(body)
    }


# ================= PARSE BODY =================
def parse_body(event):
    body = event.get("body")
    if not body:
        return {}

    try:
        return json.loads(body)
    except:
        return {}


# ================= PASSWORD =================
def generate_password():
    return (
        "Temp@"
        + random.choice(string.ascii_uppercase)
        + random.choice(string.ascii_lowercase)
        + str(random.randint(100, 999))
    )


# ================= HANDLER =================
def lambda_handler(event, context):

    print("🔥 EVENT:", json.dumps(event))

    path = event.get("rawPath", "")
    method = event.get("requestContext", {}).get("http", {}).get("method", "")

    print("PATH:", path)
    print("METHOD:", method)

    try:

        # ================= CREATE EMPLOYEE =================
        if "/create-employee" in path and method == "POST":

            body = parse_body(event)

            employee_id = str(uuid.uuid4())
            password = generate_password()

            # ================= COGNITO USER =================
            try:
                cognito_response = cognito.admin_create_user(
                    UserPoolId=os.environ["USER_POOL_ID"],
                    Username=body["email"],
                    TemporaryPassword=password,
                    MessageAction="SUPPRESS",
                    UserAttributes=[
                        {"Name": "email", "Value": body["email"]},
                        {"Name": "email_verified", "Value": "true"}
                    ]
                )

                cognito_sub = cognito_response["User"]["Username"]

                print("✅ Cognito user created")

            except Exception as e:
                print("❌ Cognito Error:", str(e))
                return response(500, {"error": "Cognito error", "details": str(e)})

            # ================= SAVE TO DYNAMODB =================
            table.put_item(Item={
                "employee_id": employee_id,
                "cognito_sub": cognito_sub,
                "email": body.get("email"),
                "department": body.get("department"),
                "role": body.get("role"),
                "manager_id": body.get("manager_id", "NA"),
                "joining_date": body.get("joining_date"),
                "employment_type": body.get("employment_type"),

                "documents": {
                    "id_proof": "pending",
                    "degree_certificate": "pending",
                    "signed_offer_letter": "pending"
                },

                "document_metadata": [],
                "created_at": datetime.utcnow().isoformat(),
                "overall_status": "IN_PROGRESS"
            })

            print("✅ DynamoDB stored")

            # ================= START STEP FUNCTION (ADDED ONLY) =================
            try:
                sfn.start_execution(
                    stateMachineArn=STATE_MACHINE_ARN,
                    input=json.dumps({
                        "employee_id": employee_id
                    })
                )
                print("🚀 Step Function started")

            except Exception as e:
                print("❌ Step Function Error:", str(e))

            # ================= SEND EMAIL =================
            try:
                ses.send_email(
                    Source=os.environ["FROM_EMAIL"],
                    Destination={
                        "ToAddresses": [body["email"]]
                    },
                    Message={
                        "Subject": {
                            "Data": "Welcome to HRMS Portal"
                        },
                        "Body": {
                            "Text": {
                                "Data": f"""
Hello {body.get("name")},

Your account has been created.

Login Email: {body.get("email")}
Temporary Password: {password}

Please login and change your password.

Regards,
HR Team
"""
                            }
                        }
                    }
                )

                print("✅ Email sent via SES")

            except Exception as e:
                print("❌ SES Error:", str(e))

            return response(200, {
                "message": "Employee created successfully",
                "employee_id": employee_id
            })


        # ================= GET ALL EMPLOYEES =================
        if "/employees" in path and method == "GET":

            data = table.scan().get("Items", [])
            result = []

            for emp in data:
                docs = emp.get("documents", {})
                pending = [k for k, v in docs.items() if v == "pending"]

                result.append({
                    "employee_id": emp.get("employee_id"),
                    "email": emp.get("email"),
                    "status": "COMPLETED" if not pending else "PENDING",
                    "pending_docs": pending
                })

            return response(200, result)


        return response(404, {
            "error": "Route not found",
            "path": path,
            "method": method
        })

    except Exception as e:
        print("🔥 GLOBAL ERROR:", str(e))
        return response(500, {"error": str(e)})