import json
import boto3
import os
from datetime import datetime

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['TABLE_NAME'])


def lambda_handler(event, context):

    try:
        employee_id = event["employee_id"]

        # ----------------------------
        # UPDATE ONLY THIS STAGE
        # ----------------------------
        table.update_item(
            Key={"employee_id": employee_id},
            UpdateExpression="""
                SET onboarding_status.policy_signoff = :v,
                    progress_percent = :progress,
                    updated_at = :time
            """,
            ExpressionAttributeValues={
                ":v": "completed",
                ":progress": 75,
                ":time": datetime.utcnow().isoformat()
            }
        )

        # ----------------------------
        # RESPONSE
        # ----------------------------
        return {
            "employee_id": employee_id,
            "stage": "policy_signoff",
            "status": "completed",
            "progress": 75
        }

    except Exception as e:
        return {
            "employee_id": event.get("employee_id", "unknown"),
            "stage": "policy_signoff",
            "status": "error",
            "error": str(e)
        }