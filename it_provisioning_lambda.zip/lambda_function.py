import json
import boto3
import os
from datetime import datetime

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['TABLE_NAME'])


def lambda_handler(event, context):

    try:
        employee_id = event["employee_id"]

        # ----------------------------
        # UPDATE ONLY THIS STAGE
        # ----------------------------
        table.update_item(
            Key={"employee_id": employee_id},
            UpdateExpression="""
                SET onboarding_status.it_provisioning = :v,
                    progress_percent = :progress,
                    updated_at = :time
            """,
            ExpressionAttributeValues={
                ":v": "completed",
                ":progress": 50,
                ":time": datetime.utcnow().isoformat()
            }
        )

        # ----------------------------
        # RESPONSE
        # ----------------------------
        return {
            "employee_id": employee_id,
            "stage": "it_provisioning",
            "status": "completed",
            "progress": 50
        }

    except Exception as e:
        return {
            "employee_id": event.get("employee_id", "unknown"),
            "stage": "it_provisioning",
            "status": "error",
            "error": str(e)
        }